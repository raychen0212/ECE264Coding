#include <stdio.h>
#include <stdlib.h>
#ifndef MAZE_H
#define MAZE_H
:( 
:) 
OwO
OuO
UwU
XDDDDDDD
^_^
QQ